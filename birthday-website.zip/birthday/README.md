# 🎂 [Friend's Name]'s Birthday Website

A cinematic, one-page birthday experience: loading screen → hero → countdown →
memory stars → timeline → photo gallery → friendship "wrapped" stats → secret
letter → cake → fireworks → ending.

## 1. Personalize it (do this first)

Open **`js/main.js`** — everything editable lives in the `CONFIG` object at the
top of the file, clearly marked with `[EDIT ME]`:

- `friendName` — shows in the hero and finale
- `memories` — 8 short quotes for the Memory Stars section
- `timeline` — year / title / description milestones
- `gallery` — captions (and photo paths once you add real photos)
- `wrapped` — the "Friendship Wrapped" stat cards. `friendshipStartDate`
  drives a live day-counter, already set to `2023-08-25`
- `letter` — the secret letter text (currently funny/sarcastic-but-sweet tone)
- `candleCount` — how many candles appear on the cake

## 2. Add real photos

Drop image files into `assets/photos/` and set the matching `src` in the
`gallery` array in `js/main.js`, e.g.:

```js
{ src: "assets/photos/us-at-the-beach.jpg", caption: "summer 2024" }
```

You can also add real photos to the `timeline` entries the same way, via each
item's `photo` field.

Until you add real files, gallery and timeline photo spots show a soft
gradient placeholder labeled `[ photo ]` — nothing breaks, they just look
unfinished.

## 3. Add background music

Drop one instrumental track at `assets/music/theme.mp3`. It will:
- start automatically right as the countdown finishes (browsers require a
  user gesture first — scrolling into the countdown section counts)
- fade in, cap at 20% volume, duck lower during the secret letter, and fade
  out at the very end
- can be muted anytime via the button, top-right

No file there yet? The site works fine silently — it just fails to play and
says nothing about it.

## 4. Easter eggs (already built in)

| Action | Effect |
|---|---|
| Press `H` | confetti burst |
| Type `friendship` anywhere | "Achievement unlocked" toast |
| Click the moon 🌙 (Memory Stars section) | shifts the accent theme |
| Click the cake 5 times | cake gives a little wiggle |
| Click the hero title | reveals a hidden line of text |

## 5. Folder structure

```
birthday/
├── index.html
├── css/
│   ├── style.css        (design tokens + layout)
│   ├── animations.css   (keyframes, reveal transitions)
│   └── responsive.css   (mobile/tablet breakpoints)
├── js/
│   ├── main.js           ← CONFIG lives here
│   ├── loader.js
│   ├── timeline.js
│   ├── gallery.js
│   ├── music.js
│   ├── confetti.js
│   └── easterEggs.js
├── assets/
│   ├── photos/
│   ├── music/
│   ├── icons/
│   ├── lottie/
│   └── fonts/
└── README.md
```

## 6. Hosting it

This is a static site — no build step. Easiest free options:
- **GitHub Pages**: push the `birthday/` folder to a repo, enable Pages
- **Netlify / Vercel**: drag-and-drop the folder onto their web dashboard
- Or just zip it and send the folder to open `index.html` locally (photos
  and music will still load fine from relative paths)

## 7. Tech used

Vanilla HTML/CSS/JS, [GSAP](https://gsap.com) (loaded but light footprint —
most motion is CSS/IntersectionObserver based), [canvas-confetti](https://www.kirilv.com/canvas-confetti/)
for bursts, and a small custom canvas particle system for the finale
fireworks. Fonts: Playfair Display, Inter, Poppins via Google Fonts.
