/* ===========================================================
   CONFETTI + FIREWORKS HELPERS
=========================================================== */
const BirthdayConfetti = (function(){

  const palette = ['#FFD166', '#FF8FB1', '#6EA8FE', '#9B7BFF', '#FFFFFF'];

  function burst(originY = 0.6){
    if (typeof confetti !== 'function') return;
    confetti({
      particleCount: 120,
      spread: 90,
      startVelocity: 45,
      origin: { x: 0.5, y: originY },
      colors: palette,
      scalar: 0.9,
      ticks: 220
    });
  }

  function sideCannons(){
    if (typeof confetti !== 'function') return;
    const end = Date.now() + 900;
    (function frame(){
      confetti({ particleCount: 4, angle: 60, spread: 55, origin: { x: 0, y: 0.7 }, colors: palette });
      confetti({ particleCount: 4, angle: 120, spread: 55, origin: { x: 1, y: 0.7 }, colors: palette });
      if (Date.now() < end) requestAnimationFrame(frame);
    })();
  }

  function softPop(x, y){
    if (typeof confetti !== 'function') return;
    confetti({
      particleCount: 26,
      spread: 60,
      startVelocity: 20,
      origin: { x, y },
      colors: palette,
      scalar: 0.6,
      gravity: 0.9
    });
  }

  // Custom canvas fireworks for the finale — independent of canvas-confetti
  function initFireworksCanvas(canvasEl){
    const ctx = canvasEl.getContext('2d');
    let particles = [];
    let running = false;
    let rafId = null;

    function resize(){
      canvasEl.width = canvasEl.clientWidth * devicePixelRatio;
      canvasEl.height = canvasEl.clientHeight * devicePixelRatio;
      ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
    }
    window.addEventListener('resize', resize);
    resize();

    function launch(x, y, color){
      const count = 44;
      for (let i = 0; i < count; i++){
        const angle = (Math.PI * 2 * i) / count;
        const speed = 1.6 + Math.random() * 2.4;
        particles.push({
          x, y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          alpha: 1,
          color,
          size: 1.6 + Math.random() * 1.6
        });
      }
    }

    function randomLaunch(){
      const w = canvasEl.clientWidth;
      const h = canvasEl.clientHeight;
      const x = w * (0.2 + Math.random() * 0.6);
      const y = h * (0.2 + Math.random() * 0.35);
      const color = palette[Math.floor(Math.random() * palette.length)];
      launch(x, y, color);
    }

    function tick(){
      const w = canvasEl.clientWidth;
      const h = canvasEl.clientHeight;
      ctx.fillStyle = 'rgba(0,0,0,0.18)';
      ctx.fillRect(0, 0, w, h);

      particles.forEach(p => {
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.02;
        p.alpha -= 0.012;
        ctx.globalAlpha = Math.max(p.alpha, 0);
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      });
      ctx.globalAlpha = 1;
      particles = particles.filter(p => p.alpha > 0);

      if (running) rafId = requestAnimationFrame(tick);
    }

    let launchInterval = null;

    return {
      start(){
        if (running) return;
        running = true;
        tick();
        randomLaunch();
        launchInterval = setInterval(randomLaunch, 850);
      },
      stop(){
        running = false;
        if (rafId) cancelAnimationFrame(rafId);
        if (launchInterval) clearInterval(launchInterval);
      }
    };
  }

  return { burst, sideCannons, softPop, initFireworksCanvas };
})();
