/* ===========================================================
   GALLERY — masonry grid + fullscreen lightbox
=========================================================== */
const BirthdayGallery = (function(){

  let photos = [];
  let currentIndex = 0;

  function render(grid, items){
    photos = items;
    grid.innerHTML = items.map((p, i) => `
      <div class="masonry-item" data-index="${i}" style="${p.src ? '' : `aspect-ratio:${p.ratio || '4/5'}; background:linear-gradient(160deg, ${p.grad || 'var(--purple), var(--blue)'});`}">
        ${p.src ? `<img src="${p.src}" alt="${p.caption || ''}" loading="lazy">` : `<div style="display:flex;align-items:center;justify-content:center;height:100%;min-height:180px;color:rgba(255,255,255,0.55);font-size:0.78rem;padding:10px;text-align:center;">[ photo ${i + 1} ]</div>`}
        <div class="masonry-caption">${p.caption || ''}</div>
      </div>
    `).join('');

    grid.querySelectorAll('.masonry-item').forEach(el => {
      el.addEventListener('click', () => openLightbox(parseInt(el.dataset.index, 10)));
    });
  }

  function openLightbox(index){
    currentIndex = index;
    updateLightbox();
    document.getElementById('lightbox').classList.add('open');
    document.getElementById('lightbox').setAttribute('aria-hidden', 'false');
  }

  function updateLightbox(){
    const p = photos[currentIndex];
    const img = document.getElementById('lightboxImg');
    const cap = document.getElementById('lightboxCaption');
    if (p.src){
      img.src = p.src;
      img.style.display = 'block';
    } else {
      img.removeAttribute('src');
      img.style.display = 'none';
    }
    cap.textContent = p.caption || '';
  }

  function closeLightbox(){
    document.getElementById('lightbox').classList.remove('open');
    document.getElementById('lightbox').setAttribute('aria-hidden', 'true');
  }

  function next(){ currentIndex = (currentIndex + 1) % photos.length; updateLightbox(); }
  function prev(){ currentIndex = (currentIndex - 1 + photos.length) % photos.length; updateLightbox(); }

  function initControls(){
    document.getElementById('lightboxClose').addEventListener('click', closeLightbox);
    document.getElementById('lightboxNext').addEventListener('click', next);
    document.getElementById('lightboxPrev').addEventListener('click', prev);
    document.getElementById('lightbox').addEventListener('click', (e) => {
      if (e.target.id === 'lightbox') closeLightbox();
    });
    document.addEventListener('keydown', (e) => {
      if (!document.getElementById('lightbox').classList.contains('open')) return;
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowRight') next();
      if (e.key === 'ArrowLeft') prev();
    });

    // basic swipe support for mobile
    let touchStartX = 0;
    const stage = document.querySelector('.lightbox-stage');
    stage.addEventListener('touchstart', (e) => { touchStartX = e.changedTouches[0].screenX; }, { passive: true });
    stage.addEventListener('touchend', (e) => {
      const dx = e.changedTouches[0].screenX - touchStartX;
      if (Math.abs(dx) > 50){ dx > 0 ? prev() : next(); }
    }, { passive: true });
  }

  return { render, initControls };
})();
