/* ===========================================================
   EASTER EGGS — small delights for anyone paying attention
=========================================================== */
const BirthdayEasterEggs = (function(){

  let toastTimeout = null;

  function showToast(message){
    let toast = document.querySelector('.toast');
    if (!toast){
      toast = document.createElement('div');
      toast.className = 'toast';
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.add('visible');
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => toast.classList.remove('visible'), 3200);
  }

  function init(){
    // Press "H" -> confetti burst
    let typedBuffer = '';
    document.addEventListener('keydown', (e) => {
      if (e.key.toLowerCase() === 'h' && !e.metaKey && !e.ctrlKey){
        BirthdayConfetti.burst(0.5);
      }

      // Type "friendship" anywhere on the page -> achievement
      if (/^[a-z]$/i.test(e.key)){
        typedBuffer = (typedBuffer + e.key.toLowerCase()).slice(-11);
        if (typedBuffer === 'friendship'){
          showToast('🏆 Achievement unlocked: Certified Bestie');
          BirthdayConfetti.sideCannons();
        }
      }
    });

    // Click the moon -> theme shift
    const moon = document.getElementById('moonEl');
    if (moon){
      moon.addEventListener('click', () => {
        document.body.classList.toggle('theme-alt');
        showToast('🌙 the sky shifted, just a little');
      });
    }

    // Click cake 5 times -> cake smiles
    const cakeEl = document.getElementById('cakeEl');
    let cakeClicks = 0;
    if (cakeEl){
      cakeEl.addEventListener('click', () => {
        cakeClicks++;
        if (cakeClicks === 5){
          showToast('🎂 the cake is smiling now');
          cakeEl.style.transition = 'transform .4s var(--ease-soft)';
          cakeEl.style.transform = 'scale(1.06) rotate(-1deg)';
          setTimeout(() => { cakeEl.style.transform = ''; }, 500);
        }
      });
    }

    // Click hero title -> tiny hidden message
    const heroTitle = document.querySelector('.hero-title');
    if (heroTitle){
      const msg = document.createElement('span');
      msg.className = 'hidden-message';
      msg.textContent = 'ok fine, you found it. i love you, weirdo.';
      heroTitle.style.position = 'relative';
      heroTitle.appendChild(msg);
      heroTitle.addEventListener('click', () => {
        msg.classList.add('visible');
        setTimeout(() => msg.classList.remove('visible'), 3000);
      });
    }
  }

  return { init };
})();
