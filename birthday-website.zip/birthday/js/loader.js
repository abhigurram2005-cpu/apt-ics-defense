/* ===========================================================
   LOADER — builds anticipation before the hero reveals
=========================================================== */
(function(){
  const messages = [
    "Initializing birthday experience…",
    "Loading memories…",
    "Collecting smiles…",
    "Preparing surprise…",
    "Ready."
  ];

  const loaderEl = document.getElementById('loader');
  const msgEl = document.getElementById('loaderMessage');
  const fillEl = document.getElementById('loaderBarFill');
  const main = document.getElementById('main');

  let step = 0;
  const totalDuration = 4400; // ~4.4s across all steps
  const stepDuration = totalDuration / messages.length;

  function nextMessage(){
    if (step < messages.length){
      msgEl.textContent = messages[step];
      fillEl.style.width = `${((step + 1) / messages.length) * 100}%`;
      step++;
      setTimeout(nextMessage, stepDuration);
    } else {
      finishLoading();
    }
  }

  function finishLoading(){
    loaderEl.style.transition = 'opacity 0.9s ease, visibility 0.9s ease';
    loaderEl.style.opacity = '0';
    main.setAttribute('aria-hidden', 'false');
    document.body.classList.add('loaded');

    setTimeout(() => {
      loaderEl.style.visibility = 'hidden';
      loaderEl.style.pointerEvents = 'none';
      window.dispatchEvent(new CustomEvent('birthday:loaded'));
    }, 900);
  }

  // Kick off once fonts/DOM are ready
  window.addEventListener('DOMContentLoaded', () => {
    setTimeout(nextMessage, 250);
  });
})();
