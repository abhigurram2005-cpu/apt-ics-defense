/* ===========================================================================
   ✎  EDIT ME — all personal content lives in this CONFIG object.
   Replace placeholder text/photos below. Nothing else in this file
   needs to change unless you want to.
=========================================================================== */
const CONFIG = {

  friendName: "Bestie", // ← put their real name here

  // 8 memory-star quotes. Keep them short — one line each.
  memories: [
    { icon: "⭐", text: "myyy lifeee myyy ruleesss" },
    { icon: "✨", text: "[EDIT ME — a memory that still makes you laugh]" },
    { icon: "🌙", text: "[EDIT ME — something only the two of you understand]" },
    { icon: "☄️", text: "[EDIT ME — a 3am phone call you still think about]" },
    { icon: "⭐", text: "[EDIT ME — the trip / plan that went sideways]" },
    { icon: "✨", text: "[EDIT ME — a moment they showed up for you]" },
    { icon: "🌟", text: "[EDIT ME — an inside joke, no context needed]" },
    { icon: "💫", text: "[EDIT ME — something you're grateful for]" },
  ],

  // Timeline milestones. Add or remove entries freely.
  timeline: [
    { year: "Aug 2023", title: "The Beginning", photo: null, desc: "We had absolutely no idea what chaos we were about to create." },
    { year: "2024", title: "[EDIT ME — a title for this chapter]", photo: null, desc: "[EDIT ME — what happened this year]" },
    { year: "2025", title: "[EDIT ME — a title for this chapter]", photo: null, desc: "[EDIT ME — what happened this year]" },
    { year: "Today", title: "Still going", photo: null, desc: "Infinite phone-call hours and counting." },
  ],

  // Gallery photos — set `src` to a real image path (e.g. "assets/photos/1.jpg")
  // to replace a placeholder block. `caption` shows on hover.
  gallery: [
    { src: null, caption: "[EDIT ME]", ratio: "4/5", grad: "var(--purple), var(--blue)" },
    { src: null, caption: "[EDIT ME]", ratio: "1/1", grad: "var(--pink), var(--purple)" },
    { src: null, caption: "[EDIT ME]", ratio: "3/4", grad: "var(--blue), var(--pink)" },
    { src: null, caption: "[EDIT ME]", ratio: "4/5", grad: "var(--purple), var(--gold)" },
    { src: null, caption: "[EDIT ME]", ratio: "1/1", grad: "var(--gold), var(--pink)" },
    { src: null, caption: "[EDIT ME]", ratio: "3/4", grad: "var(--blue), var(--purple)" },
  ],

  // Friendship Wrapped stats. friendshipStartDate powers a live day-count.
  friendshipStartDate: "2023-08-25",
  wrapped: [
    { label: "Days of friendship", type: "days-since", small: false },
    { label: "In-person hangouts", value: "[EDIT ME]", small: true },
    { label: "Phone call hours", value: "∞", small: false },
    { label: "Laugh count", value: "∞", small: false },
    { label: "Bad decisions", value: "Too many", small: true },
    { label: "Arguments", value: "Rare", small: true },
    { label: "Favorite memory", value: "\u201Cmyyy lifeee myyy ruleesss\u201D", small: true },
  ],

  // Secret letter — tone: funny & sarcastic, with real heart underneath.
  letter: `Okay so. You made it to the "emotional" part of the website, congrats,
I hope you're proud of yourself.

Look — I'm not going to pretend I planned this whole thing out of nowhere.
I built it because you deserve more than a text that says "happy bday king 🎉"
and we both know it.

[EDIT ME — swap this paragraph for something real. Maybe the thing you never
say out loud, or the reason "myyy lifeee myyy ruleesss" is somehow the most
accurate description of our friendship.]

You're one of the few people who can be unhinged with me at 2am on the phone
and somehow also be the person I trust with the real stuff. That's rare.
Don't let it go to your head. (Let it go to your head a little.)

Happy birthday. I love you, you absolute menace.`,

  candleCount: 5,
};

/* ===========================================================================
   Below this line: page wiring. Safe to leave as-is.
=========================================================================== */
(function(){

  document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('heroName').textContent = CONFIG.friendName;
    document.getElementById('finaleName').textContent = CONFIG.friendName;

    initCursor();
    initHeroCanvas();
    initScrollIndicator();
    initCountdown();
    initStars();
    BirthdayTimeline.render(document.getElementById('timelineTrack'), CONFIG.timeline);
    BirthdayGallery.render(document.getElementById('masonryGrid'), CONFIG.gallery);
    BirthdayGallery.initControls();
    initWrapped();
    initLetter();
    initCake();
    initFinale();
    initEnding();
    BirthdayMusic.init();
    BirthdayEasterEggs.init();
  });

  /* ---------- Custom cursor ---------- */
  function initCursor(){
    const dot = document.querySelector('.cursor-dot');
    const ring = document.querySelector('.cursor-ring');
    if (!dot || matchMedia('(hover:none)').matches) return;
    let rx = 0, ry = 0, tx = 0, ty = 0;
    window.addEventListener('mousemove', (e) => {
      dot.style.transform = `translate(${e.clientX}px, ${e.clientY}px) translate(-50%,-50%)`;
      tx = e.clientX; ty = e.clientY;
    });
    function loop(){
      rx += (tx - rx) * 0.18;
      ry += (ty - ry) * 0.18;
      ring.style.transform = `translate(${rx}px, ${ry}px) translate(-50%,-50%)`;
      requestAnimationFrame(loop);
    }
    loop();
    document.querySelectorAll('button, a, .star, .masonry-item, .candle').forEach(el => {
      el.addEventListener('mouseenter', () => ring.style.transform += ' scale(1.6)');
      el.addEventListener('mouseleave', () => {});
    });
  }

  /* ---------- Hero ambient particles ---------- */
  function initHeroCanvas(){
    const canvas = document.getElementById('heroCanvas');
    const ctx = canvas.getContext('2d');
    function resize(){
      canvas.width = canvas.clientWidth * devicePixelRatio;
      canvas.height = canvas.clientHeight * devicePixelRatio;
      ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
    }
    window.addEventListener('resize', resize);
    resize();

    const count = matchMedia('(max-width:640px)').matches ? 40 : 90;
    const particles = Array.from({ length: count }, () => ({
      x: Math.random() * canvas.clientWidth,
      y: Math.random() * canvas.clientHeight,
      r: Math.random() * 1.4 + 0.3,
      s: Math.random() * 0.3 + 0.05,
      o: Math.random() * 0.5 + 0.2
    }));

    function draw(){
      ctx.clearRect(0, 0, canvas.clientWidth, canvas.clientHeight);
      particles.forEach(p => {
        p.y -= p.s;
        if (p.y < -5) p.y = canvas.clientHeight + 5;
        ctx.globalAlpha = p.o;
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      });
      ctx.globalAlpha = 1;
      requestAnimationFrame(draw);
    }
    draw();
  }

  /* ---------- Scroll indicator ---------- */
  function initScrollIndicator(){
    setTimeout(() => {
      document.getElementById('scrollIndicator').classList.add('visible');
    }, 3000);
  }

  /* ---------- Countdown ---------- */
  function initCountdown(){
    const section = document.getElementById('countdown');
    const numberEl = document.getElementById('countdownNumber');
    const sequence = ['3', '2', '1', '✨'];
    let played = false;

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting && !played){
          played = true;
          BirthdayMusic.startIfNeeded();
          runSequence();
          observer.disconnect();
        }
      });
    }, { threshold: 0.6 });
    observer.observe(section);

    function runSequence(){
      let i = 0;
      numberEl.textContent = sequence[i];
      const interval = setInterval(() => {
        i++;
        if (i >= sequence.length){
          clearInterval(interval);
          BirthdayConfetti.burst(0.55);
          BirthdayConfetti.sideCannons();
          return;
        }
        numberEl.style.transition = 'none';
        numberEl.style.transform = 'scale(0.7)';
        numberEl.style.opacity = '0';
        requestAnimationFrame(() => {
          numberEl.textContent = sequence[i];
          numberEl.style.transition = 'all .5s cubic-bezier(.22,.9,.31,1)';
          numberEl.style.transform = 'scale(1)';
          numberEl.style.opacity = '1';
        });
      }, 750);
    }
  }

  /* ---------- Memory stars ---------- */
  function initStars(){
    const field = document.getElementById('starfield');
    const continueBtn = document.getElementById('starsContinue');

    const backdrop = document.createElement('div');
    backdrop.className = 'star-backdrop';
    document.body.appendChild(backdrop);

    const card = document.createElement('div');
    card.className = 'star-card';
    card.innerHTML = `
      <div class="star-card-icon" id="starCardIcon"></div>
      <p class="star-card-text" id="starCardText"></p>
      <button class="star-card-close">close</button>
    `;
    document.body.appendChild(card);
    const closeBtn = card.querySelector('.star-card-close');

    let openedCount = 0;
    const positions = generateStarPositions(CONFIG.memories.length);

    CONFIG.memories.forEach((mem, i) => {
      const star = document.createElement('button');
      star.className = 'star';
      star.style.left = positions[i].x + '%';
      star.style.top = positions[i].y + '%';
      star.setAttribute('aria-label', 'Reveal a memory');
      star.innerHTML = `<svg viewBox="0 0 24 24"><path d="M12 0l2.9 8.3L24 12l-9.1 3.7L12 24l-2.9-8.3L0 12l9.1-3.7z" fill="#FFD166"/></svg>`;

      star.addEventListener('click', () => {
        document.getElementById('starCardIcon').textContent = mem.icon;
        document.getElementById('starCardText').textContent = mem.text;
        card.classList.add('visible');
        backdrop.classList.add('visible');

        if (!star.classList.contains('opened')){
          star.classList.add('opened');
          openedCount++;
          if (openedCount === CONFIG.memories.length){
            continueBtn.hidden = false;
          }
        }
      });

      field.appendChild(star);
    });

    function closeCard(){
      card.classList.remove('visible');
      backdrop.classList.remove('visible');
    }
    closeBtn.addEventListener('click', closeCard);
    backdrop.addEventListener('click', closeCard);

    continueBtn.addEventListener('click', () => {
      document.getElementById('timeline').scrollIntoView({ behavior: 'smooth' });
    });
  }

  function generateStarPositions(n){
    // Scatter within a grid of cells so stars stay visually distinct.
    const cols = Math.ceil(Math.sqrt(n * 1.6));
    const rows = Math.ceil(n / cols);
    const positions = [];
    for (let i = 0; i < n; i++){
      const col = i % cols;
      const row = Math.floor(i / cols);
      const cellW = 90 / cols;
      const cellH = 80 / rows;
      positions.push({
        x: 5 + col * cellW + Math.random() * cellW * 0.6,
        y: 5 + row * cellH + Math.random() * cellH * 0.6
      });
    }
    return positions;
  }

  /* ---------- Friendship Wrapped ---------- */
  function initWrapped(){
    const grid = document.getElementById('wrappedGrid');
    grid.innerHTML = CONFIG.wrapped.map((stat, i) => `
      <div class="wrapped-card" style="transition-delay:${i * 0.08}s" data-type="${stat.type || ''}">
        <p class="wrapped-card-label">${stat.label}</p>
        <p class="wrapped-card-value ${stat.small ? 'small' : ''}" data-final="${stat.value || ''}">
          ${stat.type === 'days-since' ? '0' : (stat.value || '')}
        </p>
      </div>
    `).join('');

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting){
          entry.target.classList.add('in-view');
          const valueEl = entry.target.querySelector('.wrapped-card-value');
          if (entry.target.dataset.type === 'days-since'){
            animateDaysSince(valueEl);
          }
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.3 });

    grid.querySelectorAll('.wrapped-card').forEach(el => observer.observe(el));
  }

  function animateDaysSince(el){
    const start = new Date(CONFIG.friendshipStartDate);
    const days = Math.max(0, Math.floor((Date.now() - start.getTime()) / 86400000));
    const duration = 1400;
    const startTime = performance.now();
    function tick(now){
      const progress = Math.min((now - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      el.textContent = Math.floor(eased * days).toLocaleString();
      if (progress < 1) requestAnimationFrame(tick);
      else el.textContent = days.toLocaleString();
    }
    requestAnimationFrame(tick);
  }

  /* ---------- Secret letter ---------- */
  function initLetter(){
    const lockedView = document.getElementById('letterLocked');
    const openBtn = document.getElementById('openLetterBtn');
    const envelopeWrap = document.getElementById('letterEnvelope');
    const envelope = document.getElementById('envelopeEl');
    const paper = document.getElementById('letterPaper');
    const textEl = document.getElementById('letterText');

    openBtn.addEventListener('click', () => {
      lockedView.style.display = 'none';
      envelopeWrap.hidden = false;
      BirthdayMusic.duckDown();

      setTimeout(() => envelope.querySelector('.envelope-flap').classList.add('opened'), 300);

      setTimeout(() => {
        envelopeWrap.hidden = true;
        paper.hidden = false;
        typeLetter(textEl, CONFIG.letter);
      }, 1500);
    });
  }

  function typeLetter(el, text){
    let i = 0;
    const speed = 18;
    function step(){
      if (i <= text.length){
        el.textContent = text.slice(0, i);
        i += 2;
        setTimeout(step, speed);
      }
    }
    step();
  }

  /* ---------- Birthday cake ---------- */
  function initCake(){
    const row = document.getElementById('candlesRow');
    const wish = document.getElementById('cakeWish');
    const title = document.getElementById('cakeTitle');
    const section = document.getElementById('cake');
    let blownCount = 0;

    for (let i = 0; i < CONFIG.candleCount; i++){
      const candle = document.createElement('div');
      candle.className = 'candle';
      candle.innerHTML = '<div class="flame"></div>';
      candle.addEventListener('click', (e) => {
        e.stopPropagation();
        if (candle.classList.contains('blown')) return;
        candle.classList.add('blown');
        blownCount++;
        if (blownCount === CONFIG.candleCount){
          section.classList.add('dimmed');
          title.textContent = 'Make a wish.';
          setTimeout(() => {
            wish.textContent = `Here's to another year of "${CONFIG.memories[0].text}".`;
            wish.hidden = false;
            wish.classList.add('visible');
            BirthdayConfetti.burst(0.5);
          }, 700);
        }
      });
      row.appendChild(candle);
    }
  }

  /* ---------- Finale fireworks ---------- */
  function initFinale(){
    const canvas = document.getElementById('fireworksCanvas');
    const fireworks = BirthdayConfetti.initFireworksCanvas(canvas);
    let active = false;

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting && !active){
          active = true;
          fireworks.start();
          BirthdayMusic.restore();
        } else if (!entry.isIntersecting && active){
          active = false;
          fireworks.stop();
        }
      });
    }, { threshold: 0.4 });
    observer.observe(document.getElementById('finale'));
  }

  /* ---------- Ending ---------- */
  function initEnding(){
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting){
          BirthdayMusic.fadeOutFinal();
          observer.disconnect();
        }
      });
    }, { threshold: 0.5 });
    observer.observe(document.getElementById('ending'));

    document.getElementById('replayBtn').addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

})();
