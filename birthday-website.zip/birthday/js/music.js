/* ===========================================================
   MUSIC — soft instrumental loop, never loud, never forced
=========================================================== */
const BirthdayMusic = (function(){

  const MAX_VOLUME = 0.2; // hard cap at 20%, per design brief
  let audio, muted = false, fadeInterval = null, hasStarted = false;

  function init(){
    audio = document.getElementById('bgMusic');
    audio.volume = 0;

    const btn = document.getElementById('muteToggle');
    const iconOn = document.getElementById('iconSoundOn');
    const iconOff = document.getElementById('iconSoundOff');

    btn.addEventListener('click', () => {
      muted = !muted;
      iconOn.style.display = muted ? 'none' : 'block';
      iconOff.style.display = muted ? 'block' : 'none';
      if (muted){
        fadeTo(0, 400);
      } else if (hasStarted) {
        fadeTo(MAX_VOLUME, 600);
        audio.play().catch(() => {});
      }
    });
  }

  function clearFade(){
    if (fadeInterval){ clearInterval(fadeInterval); fadeInterval = null; }
  }

  function fadeTo(target, duration){
    clearFade();
    const steps = 24;
    const stepTime = duration / steps;
    const startVol = audio.volume;
    const delta = (target - startVol) / steps;
    let i = 0;
    fadeInterval = setInterval(() => {
      i++;
      audio.volume = Math.min(Math.max(startVol + delta * i, 0), 1);
      if (i >= steps){
        audio.volume = target;
        clearFade();
      }
    }, stepTime);
  }

  // Called once, ideally right as the countdown finishes —
  // browsers require a user gesture before audio can play,
  // which the countdown interaction already provides.
  function startIfNeeded(){
    if (hasStarted || muted) return;
    hasStarted = true;
    audio.play().then(() => {
      fadeTo(MAX_VOLUME, 1800);
    }).catch(() => {
      // Autoplay blocked — audio file may also be missing.
      // Fails silently; mute icon still reflects unmuted state.
    });
  }

  function duckDown(){ if (hasStarted) fadeTo(MAX_VOLUME * 0.4, 900); }
  function restore(){ if (hasStarted && !muted) fadeTo(MAX_VOLUME, 900); }
  function fadeOutFinal(){ fadeTo(0, 2500); }

  return { init, startIfNeeded, duckDown, restore, fadeOutFinal };
})();
