/* ===========================================================
   TIMELINE — renders milestones and reveals on scroll
=========================================================== */
const BirthdayTimeline = (function(){

  function render(track, items){
    track.innerHTML = items.map((item) => `
      <div class="timeline-item">
        <div class="timeline-dot"></div>
        <div class="timeline-card">
          <p class="timeline-year">${item.year}</p>
          <h3 class="timeline-card-title">${item.title}</h3>
          <div class="timeline-photo">
            ${item.photo ? `<img src="${item.photo}" alt="${item.title}">` : `<span>[ photo: ${item.title} ]</span>`}
          </div>
          <p class="timeline-desc">"${item.desc}"</p>
        </div>
      </div>
    `).join('');

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting){
          entry.target.classList.add('in-view');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.25 });

    track.querySelectorAll('.timeline-item').forEach(el => observer.observe(el));
  }

  return { render };
})();
